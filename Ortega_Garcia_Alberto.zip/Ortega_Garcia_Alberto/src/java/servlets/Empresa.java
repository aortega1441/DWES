/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlets;

/**
 *
 * @author alumno
 */
public class Empresa {

    private String empresa;
    private String cif;
    private String representante;
    private String nif;
    private String sector;
    private String telefono;
    private String email;
    private String ventas;
    private String observaciones;

    public Empresa(String empresa, String cif, String representante, String nif, String sector, String telefono, String email, String ventas, String observaciones) throws CIF_Exception, DNI_Exception, TEL_Exception {
        this.setEmpresa(empresa);
        this.setCif(cif);
        this.setRepresentante(representante);
        this.setNif(nif);
        this.setSector(sector);
        this.setTelefono(telefono);
        this.setEmail(email);
        this.setVentas(ventas);
        this.setObservaciones(observaciones);
    }

    public String getEmpresa() {
        return empresa;
    }

    public String getCif() {
        return cif;
    }

    public String getRepresentante() {
        return representante;
    }

    public String getNif() {
        return nif;
    }

    public String getSector() {
        return sector;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }

    public String getVentas() {
        return ventas;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public void setCif(String cif) throws CIF_Exception {
        this.cif = compruebaCif(cif);
    }

    public void setRepresentante(String representante) {
        this.representante = representante;
    }

    public void setNif(String nif) throws DNI_Exception {
        this.nif = compruebaNif(nif);
    }

    public void setSector(String sector) {
        this.sector = sector;
    }

    public void setTelefono(String telefono) throws TEL_Exception {
        this.telefono = compruebaTelefono(telefono);
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setVentas(String ventas) {
        this.ventas = ventas;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public String toString() {
        return "empresa{" + "empresa=" + empresa + ", cif=" + cif + ", representante=" + representante + ", nif=" + nif + ", sector=" + sector + ", telefono=" + telefono + ", email=" + email + ", ventas=" + ventas + ", observaciones=" + observaciones + '}';
    }

    private String compruebaCif(String cif) throws CIF_Exception {

        int tamano = cif.length();

        if (tamano == 9) {

            String tipo_organizacion = Character.toString(cif.charAt(0));
            String[] letras_tipo_organizacion = {"A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "U", "V", "W"};
            boolean tipo_organizacion_correcto = false;

            for (int x = 0; x < letras_tipo_organizacion.length; x++) {
                if (tipo_organizacion.equals(letras_tipo_organizacion[x])) {
                    tipo_organizacion_correcto = true;
                    break;
                }
            }

            String codigo_provincia = cif.substring(1, 3);
            String[] array_codigo_provincia = {"01", "02", "03", "53", "54", "04", "05", "06", "07", "57", "08", "58", "59", "60", "61", "62", "63", "64", "09",
                "10", "11", "72", "12", "13", "14", "56", "15", "70", "16", "17", "55", "18", "19", "20", "71", "21", "22", "23",
                "24", "25", "26", "27", "28", "78", "79", "80", "81", "82", "83", "84", "85", "29", "92", "93", "30", "73", "31",
                "32", "33", "74", "34", "35", "76", "36", "94", "37", "38", "75", "39", "40", "41", "91", "42", "43", "77", "44",
                "45", "46", "96", "97", "98", "47", "48", "95", "49", "50", "99", "51", "52"};
            boolean codigo_provincia_correcto = false;

            for (int x = 0; x < array_codigo_provincia.length; x++) {
                if (codigo_provincia.equals(array_codigo_provincia[x])) {
                    codigo_provincia_correcto = true;
                    break;
                }
            }

            char caracter_control = cif.charAt(8);
            boolean caracter_control_correcto = true;

            if ((tipo_organizacion.equals("K") || tipo_organizacion.equals("P") || tipo_organizacion.equals("Q") || tipo_organizacion.equals("S")) && Character.isDigit(caracter_control)) {
                caracter_control_correcto = false;
            } else if ((tipo_organizacion.equals("A") || tipo_organizacion.equals("B") || tipo_organizacion.equals("E") || tipo_organizacion.equals("H")) && !Character.isDigit(caracter_control)) {
                caracter_control_correcto = false;
            }

            String numero_correlativo = cif.substring(3, 8);
            boolean numero_correlativo_correcto = true;

            for (int x = 0; x < numero_correlativo.length(); x++) {
                char caracter = numero_correlativo.charAt(x);
                if (!Character.isDigit(caracter)) {
                    numero_correlativo_correcto = false;
                    break;
                }
            }

            if (numero_correlativo_correcto && caracter_control_correcto && codigo_provincia_correcto && tipo_organizacion_correcto) {
                return cif;
            } else {
                throw new CIF_Exception();
            }

        } else {
            throw new CIF_Exception();
        }

    }

    private String compruebaNif(String dni) throws DNI_Exception {

        boolean correcto = false;
        char[] letras = {'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'};
        char letra = dni.charAt(8);
        int numeros = Integer.parseInt(dni.substring(0, 8));
        int resto = numeros % 23;

        if (letra == letras[resto]) {
            correcto = true;
        }

        if (correcto) {
            return dni;
        } else {
            throw new DNI_Exception();
        }

    }

    private String compruebaTelefono(String telefono) throws TEL_Exception {

        int tam = telefono.length();

        if (tam == 12) {

            String tel = telefono.substring(1, telefono.length() - 1);
            boolean correcto = true;
            String mas = Character.toString(telefono.charAt(0));

            for (int x = 0; x < tel.length(); x++) {
                char caracter = tel.charAt(x);
                if (!Character.isDigit(caracter)) {
                    correcto = false;
                    break;
                }
            }

            if (mas.equals("+") && correcto) {
                return telefono;
            } else {
                throw new TEL_Exception();
            }

        } else {
            throw new TEL_Exception();
        }

    }

}
